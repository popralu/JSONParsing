package com.example.jsonparsing

import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class UserViewHolder(view: View) : RecyclerView.ViewHolder(view) {
    // Holds the TextView that will add each item to
    var  tvId : TextView
    var tvName : TextView
    var tvEmail : TextView
    var tvGender : TextView
    var tvWeight : TextView
    var tvHeight : TextView
    var tvMobileNumber : TextView
    var tvOfficeNumber : TextView

    init {
        tvId = view.findViewById(R.id.tv_id)
        tvName = view.findViewById(R.id.tv_name)
        tvEmail = view.findViewById(R.id.tv_email)
        tvGender = view.findViewById(R.id.tv_gender)
        tvWeight = view.findViewById(R.id.tv_weight)
        tvHeight = view.findViewById(R.id.tv_height)
        tvMobileNumber = view.findViewById(R.id.tv_mobile)
        tvOfficeNumber = view.findViewById(R.id.tv_office_number)
    }

    fun bind(item: UserModelClass) {
        tvId.text = item.id.toString()
        tvName.text = item.name
        tvEmail.text = item.email
        tvGender.text = item.gender
        tvWeight.text = item.weight.toString()
        tvHeight.text = item.height.toString()
        tvMobileNumber.text = item.mobile
        tvOfficeNumber.text = item.office
    }
}